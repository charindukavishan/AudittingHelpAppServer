var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'mysql1005.mochahost.com',
  user     : 'ano119_exigo',
  password : 'exig0@M5web',
  database : 'ano119_exigoDB',
});
connection.connect(function(err){
if(!err) {
    console.log("Database is connected");
} else {
    console.log(err);
}
});
module.exports = connection; 

require('./user.model');